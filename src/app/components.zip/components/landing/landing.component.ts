import { Component } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { BrickDetailsComponent } from '../popup/brick-details/brick-details.component';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent {
  modalRef!: BsModalRef;

  constructor(private modalService: BsModalService) {}

  openBrickModal() {
    this.modalRef = this.modalService.show(BrickDetailsComponent, {
      class: 'modal-dialog-slide-up'
    });
  }
}
