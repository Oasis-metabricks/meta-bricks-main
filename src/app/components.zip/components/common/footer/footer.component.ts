import { Component } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { WhatComponent } from '../../popup/what/what.component';
import { HowComponent } from '../../popup/how/how.component';
import { WhitepaperComponent } from '../../popup/whitepaper/whitepaper.component';
import { DeliverableComponent } from '../../popup/deliverable/deliverable.component';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
  modalRef!: BsModalRef;

  constructor(private modalService: BsModalService) {}

  openWhatModal() {
    this.modalRef = this.modalService.show(WhatComponent);
  }

  openHowModal() {
    this.modalRef = this.modalService.show(HowComponent);
  }

  openWhitepaperModal() {
    this.modalRef = this.modalService.show(WhitepaperComponent);
  }

  openDeliverableModal() {
    this.modalRef = this.modalService.show(DeliverableComponent);
  }
}
