import { Component } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ShareReferralsComponent } from '../share-referrals/share-referrals.component';
import { MintComponent } from '../mint/mint.component';

@Component({
  selector: 'app-brick-details',
  templateUrl: './brick-details.component.html',
  styleUrls: ['./brick-details.component.scss']
})
export class BrickDetailsComponent {
  modalRef!: BsModalRef;

  constructor(private modalService: BsModalService) {}

  openShareModal() {
    this.modalRef = this.modalService.show(ShareReferralsComponent);
  }

  openMintModal() {
    this.modalRef = this.modalService.show(MintComponent);
  }
}
