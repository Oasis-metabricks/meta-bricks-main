const express = require('express');
const bodyParser = require('body-parser');
const purchaseHandler = require('./purchaseHandler');
const brickWallState = require('./brickWallState');

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.post('/purchase', purchaseHandler);
app.get('/bricks', brickWallState.getBricks);

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
